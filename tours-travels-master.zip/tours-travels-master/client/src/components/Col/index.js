export { default } from "./Col";
