export { default } from "./Needtoknow.js";
