var express= require('express');
var app=express();




function login(){
    return(home.html) ;
}
function register(){
    alert("hello plz register");
}
